
README.txt
----------
Recovered fragments from an unknown narrative project.
Some files appear poetic, others are recursive command syntax.

We are unsure if this is art, a lost AI language, or both.

For archival purposes only.
